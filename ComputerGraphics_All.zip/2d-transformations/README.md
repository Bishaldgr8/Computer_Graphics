2D transforms (translation, rotation, scaling, shear) are represented using 3×3 homogeneous matrices. Composition is matrix multiplication, enabling concatenated transforms and coordinate frame changes.

# 2D Geometric Transformations

L A B
E X P E R I M E N T :

2D
TRANSFORMA TIONS
OBJECTIVE:
To
explore
and
implement
various
2D
transformations
such
as
translation
,
scaling
,
r otation
,
and
r eflection
on
basic
2D
objects.
The
objective
is
to
understand
their
mathematical
representation
and
observe
how
these
transformations
affect
the
position,
size,
and
orientation
of
the
objects.
THEOR Y :
2D
transformations
involve
manipulating
objects
in
a
2D
plane
by
altering
their
geometry ,
position,
or
orientation.
These
operations
are
commonly
performed
using
matrix
r epr esentations
,
which
simplify
combining
multiple
transformations.
Key
T ransformations:
●
T ranslation:
Moves
an
object
without
changing
its
shape
or
orientation.
●
Scaling:
Alters
the
size
of
an
object
proportionally .
●
Rotation:
Rotates
an
object
around
a
fixed
point
(usually
the
origin).
●
Reflection:
Flips
an
object
across
a
specified
axis
or
line.
Key
Concepts:

1.
T ransformation
Matrices:
○
T ranslation
Matrix:
T=[10tx01ty001]T= 100 010 txty1  
○
Scaling
Matrix:
S=[sx000sy0001]S= sx00 0sy0 001  
○
Rotation
Matrix:
R=[cos
 
θ−
sin
 
θ0
sin
 
θ
cos
 
θ0001]
R= cos
θ
sin
θ0 −
sin
θ
cos
θ0 001  
○
Reflection
Matrix
(acr oss
x-axis):
M=[1000−10001]M= 100 0−10 001  
2.
T ransformation
Sequence:
○
The
order
of
applying
transformations
is
critical.
For
example,
translating
an
object
first
and
then
rotating
it
gives
a
different
result
than
rotating
first
and
then
translating.
○
Transformations
can
be
combined
using
matrix
multiplication
for
efficiency .
E x p e r i m e n t a t i o n
P r o c e d u r e
1.
S e t
U p
t h e
E n v i r o n m e n t :
Use
a
graphical
library
(e.g.,
Pygame,
OpenGL)
to
create
a
2D
canvas
for
drawing
and
applying
transformations.
2.
Draw
2D
Objects:
Create
simple
shapes
like
lines,
triangles,
rectangles,
or
polygons.
3.
Apply
T ransformations:
○
T ranslation:
Move
the
object
by
applying
a
translation
matrix.
○
Scaling:
Resize
the
object
using
a
scaling
matrix.
○
Rotation:
Rotate
the
object
about
a
point
by
applying
a
rotation
matrix.
○
Reflection:
Flip
the
object
across
the
x-axis,
y-axis,
or
any
arbitrary
line.
4.
Combine
T ransformations:
Use
matrix
multiplication
to
combine
transformations
(e.g.,
scale
then
rotate),
and
visualize
the
effects
of
changing
the
order
of
operations.
5.
V isualize
Results:
Render
both
the
original
object
and
the
transformed
object
side
by
side
for
comparison.
C o d e
I m p l e m e n t a t i o n
result.

L e a r n i n g
O u t c o m e
●
Understand
and
apply
basic
2D
transformations:
translation,
scaling,
rotation,
and
reflection.
●
Gain
insight
into
matrix-based
transformation
techniques.
●
Develop
an
understanding
of
how
transformation
sequences
influence
the
geometry
and
placement
of
objects

61

## Build & Run

```bash
g++ -std=c++17 2d_transformations.cpp -o app
./app
```
