The Midpoint Ellipse algorithm generalizes midpoint rasterization to ellipses. It separates region-1 and region-2 traversal based on slope, updating a decision parameter to select pixels using only additions.

# Midpoint Ellipse

L A B
E X P E R I M E N T :

MIDPOINT
ELLIPSE
GENERA TION
ALGORITHM:
O b j e c t i v e
To
implement
the
Midpoint
Ellipse
Generation
Algorithm
and
understand
its
use
in
efficiently
plotting
an
ellipse
on
a
raster
grid.
T h e o r y
The
Midpoint
Ellipse
Algorithm
is
a
rasterization
technique
in
computer
graphics
used
to
draw
ellipses
efficiently .
It
works
similarly
to
the
Midpoint
Circle
Algorithm
but
incorporates
additional
calculations
due
to
the
different
radii
of
an
ellipse.
The
algorithm
leverages
symmetry
and
integer
arithmetic
to
determine
the
points
on
the
ellipse.
K e y
C o n c e p t s
1.
E l l i p s e
E q u a t i o n
The
equation
of
an
ellipse
is:
x2rx2+y2ry2=1rx2 x2 +ry2 y2 =1
Here,
rxrx 
is
the
horizontal
radius,
ryry 
is
the
vertical
radius,
and
(x,y)(x,y)
are
the
points
on
the
ellipse.
2.
Regions
○
Region

:
Where
the
slope
of
the
ellipse
is
less
than
or
equal
to
1.
Points
are
incrementally
plotted
along
the
x-axis.
○
Region

:
Where
the
slope
is
greater
than
1.
Points
are
incrementally
plotted
along
the
y-axis.
3.
Symmetry
Points
are
computed
for
one
quadrant
and
reflected
across
axes
to
cover
all
four
quadrants.
A l g o r i t h m
S t e p s
1.
Region
1:
○
Start
plotting
from
(0,ry)(0,ry )
and
move
horizontally
along
the
x-axis.

○
Calculate
the
decision
parameter
to
determine
whether
to
increment
the
y-coordinate.
○
Continue
until
the
slope
becomes
greater
than
1.
2.
Region
2:
○
Switch
to
vertical
movement
along
the
y-axis,
computing
corresponding
x-coordinates.
○
Continue
until
the
ellipse
is
fully
plotted
in
one
quadrant.
3.
Symmetry:
Reflect
the
calculated
points
across
axes
to
complete
the
ellipse.
P r o c e d u r e
1.
Implement
the
Midpoint
Ellipse
Algorithm
as
a
function.
2.
Take
the
center
of
the
ellipse
(xc,yc)(xc ,yc )
and
radii
(rx,ry)(rx ,ry )
as
inputs.
3.
Initialize
the
decision
variables
and
compute
points
for
Region
1.
4.
Switch
to
Region

after
Region

completes.
5.
Use
symmetry
to
plot
points
in
all
four
quadrants.
6.
Display
the
computed
pixel
coordinates
and
visualize
the
ellipse.
C o d e
I m p l e m e n t a t i o n

## Build & Run

```bash
g++ -std=c++17 midpoint_ellipse.cpp -o app
./app
```
