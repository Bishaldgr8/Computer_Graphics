Projection maps 3D view-space points to 2D via a projection matrix. Orthographic preserves parallelism; perspective applies foreshortening with a depth-dependent divide by w.

# Projections (Ortho/Perspective)

L A B
E X P E R I M E N T :
2 0
PROJECTIONS
OBJECTIVE
To
understand
and
implement
various
types
of
projections
in
computer
graphics,
including
parallel
and
perspective
projections,
for
rendering
3D
objects
onto
a
2D
plane.
HARDW ARE
ENVIRONMENT
1.
Pr ocessor
:
Intel
Core
i3
or
higher .
2.
RAM
:

GB
or
more.
3.
Graphics
:
Integrated
or
dedicated
GPU
supporting
OpenGL.
SOFTW ARE
ENVIRONMENT
1.
Operating
System
:
Windows/Linux/macOS.
2.
Pr ogramming
Language
:
C++
with
OpenGL
and
GLUT
libraries.
3.
Compiler
:
GCC
or
equivalent
supporting
OpenGL.
THEOR Y
In
computer
graphics,
pr ojections
are
transformations
that
map
3D
points
to
a
2D
plane
for
display .
They
help
simulate
how
objects
are
viewed
in
the
real
world
or
in
technical
applications.
T ypes
of
Pr ojections
1.
Parallel
Pr ojection
○
Projects
3D
points
along
parallel
lines
onto
a
2D
plane.
○
Common
Types:
■
Orthographic
Pr ojection
:
Maintains
true
dimensions
of
the
object.

■
Oblique
Pr ojection
:
Combines
orthographic
projection
with
a
skewed
perspective.
2.
Perspective
Pr ojection
○
Simulates
how
objects
appear
smaller
as
they
move
further
from
the
viewer ,
mimicking
human
vision.
○
Creates
a
realistic
depth
effect.
Pr ojection
Matrices
1.
Orthographic
Pr ojection
Matrix
Portho=[2r−l00−r+lr−l02t−b0−t+bt−b00−2f−n−f+nf−n0001]Portho = r−l2 000 0t−b2 00 00−f−n2 0 
−r−lr+l −t−bt+b −f−nf+n 1  
2.
Perspective
Pr ojection
Matrix
Ppersp=[2nr−l0r+lr−l002nt−bt+bt−b000−f+nf−n−2fnf−n00−10]Ppersp = r−l2n 000 0t−b2n 00 r−lr
+l t−bt+b −f−nf+n −1 00−f−n2fn 0  
Where:
●
l,rl,r:
Left
and
right
planes.
●
b,tb,t:
Bottom
and
top
planes.
●
n,fn,f:
Near
and
far
planes.
EXPERIMENT A TION
PROCEDURE
1.
Setup
the
Envir onment
○
Initialize
OpenGL
and
GLUT .
○
Define
a
3D
object,
such
as
a
cube.
2.
Orthographic
Pr ojection
○
Set
the
orthographic
projection
matrix
using
glOrtho
.
○
Render
the
object
with
true
dimensions,
ignoring
depth.
3.
Perspective
Pr ojection

○
Set
the
perspective
projection
matrix
using
gluPerspective
or
a
custom
matrix.
○
Render
the
object
with
realistic
depth
effects.
4.
Comparison
○
Visualize
and
compare
the
outputs
of
both
projections.
CODE
OUTPUT
1.
Orthographic
Pr ojection
○
Displays
the
cube
without
depth
effects.
The
dimensions
remain
accurate
regardless
of
distance
from
the
camera.
2.
Perspective
Pr ojection
○
Displays
the
cube
with
depth
effects,
where
distant
parts
appear
smaller
than
closer
parts.
INFERENCE
●
Orthographic
Pr ojection
is
ideal
for
technical
drawings
where
maintaining
true
dimensions
is
essential.
●
Perspective
Pr ojection
provides
a
more
realistic
representation,
making
it
suitable
for
applications
like
games
and
simulations.

LEARNING
OUTCOMES
1.
Understood
the
theoretical
differences
between
parallel
and
perspective
projections.
2.
Implemented
both
projection
techniques
using
OpenGL.
3.
Learned
to
switch
between
projection
modes
and
visualize
their
effects
in
a
graphics
pipeline.
113

## Build & Run

```bash
g++ -std=c++17 projections.cpp -o app
./app
```
