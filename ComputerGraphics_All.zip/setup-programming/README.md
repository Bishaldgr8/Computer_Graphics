This setup configures the C++ graphics toolchain (e.g., Visual Studio + DirectX SDK). It ensures compilers, libraries, and include/lib paths are properly installed to build graphics applications.

# Programming Environment Setup

L A B
E X P E R I M E N T :

SETTING
UP
PROGRAMMING
ENVIRONMENT
OBJECTIVE:
The
objective
of
this
lab
is
to
set
up
a
programming
environment
for
computer
graphics 
development
using
Visual
Studio

Community
Edition
with
DirectX.
This 
configuration
will
facilitate
the
development
of
C++
applications
that
utilize
DirectX 
libraries
to
render
high-quality
graphics.
HARDW ARE
REQUIREMENTS
:
●
P r o c e s s o r :
Intel
Core
i5
or
higher 
●
R A M :
Minimum

GB
(16
GB
recommended) 
●
S t o r a g e :
At
least

GB
of
free
disk
space 
●
G r a p h i c s
C a r d :
DirectX
11/12
compatible
GPU
(e.g.,
Nvidia
or
AMD) 
●
M o n i t o r :
Full
HD
(1920x1080)
or
higher
resolution
recommended
S O F T W A R E
R E Q U I R E M E N T S :
●
O p e r a t i n g
S y s t e m :
Windows

or
later 
●
I n t e g r a t e d
D e v e l o p m e n t
E n v i r o n m e n t
( I D E ) :
Visual
Studio

Community
Edition 
●
S D K :
DirectX
SDK
(required
for
older
versions
like
DirectX
9) 
●
P r o g r a m m i n g
L a n g u a g e :
C++ 
●
A d d i t i o n a l
T o o l s : 
○
Microsoft
Windows
SDK
(included
with
Visual
Studio
installation) 
○
DirectX
runtime
THEOR Y :
DirectX
is
a
robust
suite
of
APIs
designed
for
multimedia
tasks,
particularly
in
game 
development
and
video
rendering.
It
facilitates
interaction
with
the
GPU,
ensuring
efficient 
rendering
of
2D
and
3D
graphics.
Visual
Studio,
a
widely
used
IDE
for
C++
development,
integrates
seamlessly
with
DirectX. 
This
combination
empowers
developers
to
create
high-performance
graphics
applications
by 
leveraging
DirectX
APIs
to
render
3D
scenes
and
efficiently
manage
real-time
rendering
tasks.
E X P E R I M E N T A T I O N
P R O C E D U R E :
1.
D o w n l o a d
a n d
I n s t a l l
V i s u a l
S t u d i o
2 0 2 2
C o m m u n i t y
E d i t i o n :

○
Visit
the
official
Visual
Studio
website
and
download
the
Community
Edition 
installer . 
○
Run
the
installer
and
select
the
"Desktop
development
with
C++"
workload 
during
installation.
2.
Set
Up
the
Dir ectX
Development
Envir onment: 
○
Install
any
required
DirectX
SDKs
if
working
with
older
versions
like
DirectX
9. 
○
Ensure
the
DirectX
runtime
is
installed
on
your
system. 
3.
Cr eate
a
New
C++
Pr oject
in
V isual
Studio: 
○
Open
Visual
Studio
and
create
a
new
C++
Console
App
project. 
○
Configure
the
project
to
include
DirectX
libraries
and
headers. 
4.
W rite
and
Compile
a
Basic
Dir ectX
Application:
○
Include
essential
DirectX
headers,
such
as
d3d11.h
.
○
Write
a
basic
DirectX
program
to
initialize
a
rendering
device
and
clear
the 
screen
with
a
color . 
5.
T est
and
Debug:
○
Build
and
run
the
application. 
○
Use
Visual
Studio's
debugger
to
identify
and
resolve
any
errors
or
issues.
D E T A I L E D
S T E P S :
1.
I n s t a l l
R e q u i r e d
W o r k l o a d s : 
○
During
the
Visual
Studio
installation,
ensure
the
following
workloads
are 
selected:
■
Desktop
development
with
C++ 
■
Game
development
with
C++
(includes
DirectX
tools
and
libraries) 
○
These
workloads
will
install
the
necessary
compilers,
SDKs,
and
libraries 
automatically .

2.
V erify
Dir ectX
Installation: 
○
DirectX
11/12
is
included
with
the
Windows
SDK.
Verify
its
installation
by 
checking
the
presence
of
DirectX
libraries
at: 
C:\Program
Files
(x86)\Windows
Kits\
○
For
DirectX
9,
download
and
install
the
DirectX
SDK
separately . 
3.
Set
Up
a
New
Pr oject: 
○
Open
Visual
Studio
and
create
a
new
project: 
■
Go
to
File
>
New
>
Pr oject. 
■
Select
C++
>
W indows
Desktop
>
W indows
Desktop
Application. 
■
Name
the
project
and
configure
the
settings
as
required.
4.
Include
Dir ectX
Libraries: 
○
In
the
project
properties,
add
the
DirectX
libraries
and
configure
the
SDK
path
if 
required:

■
Navigate
to
Pr oject
>
Pr operties
>
VC++
Dir ectories
and
include 
DirectX
SDK
paths
(if
using
DirectX
9).
■
Link
necessary
libraries
such
as
d3d11.lib
,
d3d12.lib
,
etc.
5.
W rite
Basic
Dir ectX
Code: 
○
Write
a
simple
C++
program
to
initialize
a
DirectX
rendering
context
and 
display
a
graphics
window . 
○
Compile
and
execute
the
program
to
confirm
proper
functionality .
T Y P I C A L
O U T P U T :
Upon
successful
completion,
the
program
should
compile
and
execute,
producing
a
basic 
window
with
a
blank
screen
or
a
solid
color
fill.
This
indicates
that
the
DirectX
context
has 
been
correctly
initialized
and
is
ready
for
further
development.
I N F E R E N C E :
Setting
up
a
development
environment
for
DirectX
using
Visual
Studio
involves
installing
the 
appropriate
components
such
as
SDKs
and
libraries.
Visual
Studio
simplifies
the
configuration 
and
debugging
process,
enabling
developers
to
focus
on
building
advanced
computer
graphics 
applications.
L E A R N I N G
O U T C O M E :
●
Gained
knowledge
of
setting
up
Visual
Studio

for
C++
and
DirectX
development. 
●
Learned
how
to
configure
project
settings
for
DirectX
integration. 
●
Successfully
compiled
and
executed
a
basic
application
using
DirectX
for
rendering.
8

## Build & Run

```bash
g++ -std=c++17 setup_programming.cpp -o app
./app
```
