This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.

# E X P E R I M E N T 1 5 N A T U R A L C U B I C S P L I N E

L A B
E X P E R I M E N T :
1 5
N A T U R A L
C U B I C
S P L I N E
O B J E C T I V E
To
understand
and
implement
natural
cubic
spline
interpolation,
creating
smooth
curves
passing
through
a
set
of
given
points.
This
experiment
aims
to
explore
the
generation
and
manipulation
of
cubic
splines
for
achieving
smooth
transitions
between
data
points
and
studying
their
applications
in
computer
graphics
and
data
modeling.
T H E O R Y
A
natural
cubic
spline
is
a
piecewise-defined
cubic
polynomial
used
for
interpolating
a
set
of
points.
The
resulting
curve
is
smooth
at
the
joins
between
polynomial
segments
and
satisfies
the
following
properties:
1.
Piecewise
Polynomials
Each
segment
between
points
(xi,yi)(xi ,yi )
is
defined
by
a
cubic
polynomial:
Si(x)=ai+bi(x−xi)+ci(x−xi)2+di(x−xi)3Si (x)=ai +bi (x−xi )+ci (x−xi )2+di (x−xi )3
2.
Continuity
Conditions
○
First
Derivative
Continuity
:
The
first
derivative
is
continuous
across
all
intervals.
○
Second
Derivative
Continuity
:
The
second
derivative
is
continuous
across
all
intervals.
3.
Natural
Boundary
Conditions
○
The
second
derivative
at
the
endpoints
is
zero
(S′′(x0)=0S′′(x0 )=0
and
S′′(xn)=0S′′(xn )=0).
○
This
ensures
a
"natural"
behavior
where
the
curvature
flattens
at
the
boundaries.
4.
Cubic
Spline
Interpolation
○
The
spline
passes
through
all
given
points
(xi,yi)(xi ,yi ).

○
It
minimizes
the
total
curvature
of
the
curve,
providing
smoother
results
than
linear
or
polynomial
interpolation.
5.
System
of
Equations
The
coefficients
ai,bi,ci,diai ,bi ,ci ,di 
are
calculated
by
solving
a
system
of
linear
equations
derived
from
continuity
and
boundary
conditions.
C O D E
cpp
Copy
code

## Build & Run

```bash
g++ -std=c++17 e_x_p_e_r_i_m_e_n_t_1_5_n_a_t_u_r_a_l_c_u_b_i_c_s_p_l_i_n_e.cpp -o app
./app
```
