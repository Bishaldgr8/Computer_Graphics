# Computer Graphics Lab — C++ Implementations
This repository contains individual experiment folders for classic computer graphics algorithms and tasks. Each folder includes a C++ source file and a README with a technical overview and usage.
## System Requirements
- C++17-compliant compiler (GCC/Clang/MSVC)
- (If required) Graphics libraries such as `<graphics.h>`/OpenGL/DirectX, depending on the experiment
- A terminal or IDE (VS Code, Visual Studio, Code::Blocks)
## Build & Run (generic)
```bash
# from a specific experiment folder
g++ -std=c++17 <file>.cpp -o app
./app
```
## Folder Structure
- [setup-programming](./setup-programming/) — This setup configures the C++ graphics toolchain (e.g., Visual Studio + DirectX SDK). It ensures compilers, libraries, and include/lib paths are properly installed to build graphics applications.
- [dda-algorithm](./dda-algorithm/) — The Digital Differential Analyzer (DDA) algorithm linearly interpolates x and y using the slope m = Δy/Δx. It increments the dominant axis in unit steps and computes the minor axis with floating-point additions, yielding evenly sampled raster positions along a line segment.
- [bresenham-line](./bresenham-line/) — Bresenham’s line rasterizer uses an integer error term to choose between two neighboring pixels each step. It avoids floating-point arithmetic by maintaining a decision variable derived from the implicit line equation, providing efficient, visually continuous straight lines.
- [midpoint-circle](./midpoint-circle/) — The Midpoint Circle algorithm exploits eight-way symmetry and a midpoint decision parameter to step around a circle. At each iteration it selects E or SE pixels based on the sign of the implicit circle function, requiring only integer updates.
- [midpoint-ellipse](./midpoint-ellipse/) — The Midpoint Ellipse algorithm generalizes midpoint rasterization to ellipses. It separates region-1 and region-2 traversal based on slope, updating a decision parameter to select pixels using only additions.
- [e-x-p-e-r-i-m-e-n-t-crea-ting-2d-objects](./e-x-p-e-r-i-m-e-n-t-crea-ting-2d-objects/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [e-x-p-e-r-i-m-e-n-t-2d-anima-tion-and-game-design](./e-x-p-e-r-i-m-e-n-t-2d-anima-tion-and-game-design/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [e-x-p-e-r-i-m-e-n-t-coloring-pictures-and-primitive-a-ttributes](./e-x-p-e-r-i-m-e-n-t-coloring-pictures-and-primitive-a-ttributes/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [2d-transformations](./2d-transformations/) — 2D transforms (translation, rotation, scaling, shear) are represented using 3×3 homogeneous matrices. Composition is matrix multiplication, enabling concatenated transforms and coordinate frame changes.
- [e-x-p-e-r-i-m-e-n-t-1-0-super-sampling-anti-aliasing-33](./e-x-p-e-r-i-m-e-n-t-1-0-super-sampling-anti-aliasing-33/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [cohen-sutherland](./cohen-sutherland/) — Cohen–Sutherland classifies endpoints into outcodes relative to a rectangular clip window. Bitwise trivial accept/reject and parametric boundary intersections iteratively clip the segment to the view volume.
- [liang-barsky](./liang-barsky/) — Liang–Barsky uses the parametric form P(t) = P0 + t·d and inequalities for the clip window to compute entering/exiting t values. It minimizes intersection tests and is more efficient than Cohen–Sutherland for many cases.
- [e-x-p-e-r-i-m-e-n-t-1-3-3d-object-crea-tion](./e-x-p-e-r-i-m-e-n-t-1-3-3d-object-crea-tion/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [e-x-p-e-r-i-m-e-n-t-1-4-system-of-n-degree-n](./e-x-p-e-r-i-m-e-n-t-1-4-system-of-n-degree-n/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [e-x-p-e-r-i-m-e-n-t-1-5-n-a-t-u-r-a-l-c-u-b-i-c-s-p-l-i-n-e](./e-x-p-e-r-i-m-e-n-t-1-5-n-a-t-u-r-a-l-c-u-b-i-c-s-p-l-i-n-e/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [bezier-curve](./bezier-curve/) — A Bézier curve is defined by control points and Bernstein polynomials. De Casteljau’s algorithm evaluates the curve via recursive linear interpolation, offering numerical stability and affine invariance.
- [b-spline-curve](./b-spline-curve/) — Uniform B-splines blend local control points using basis functions over knot spans. They provide C2 continuity (for cubic) and local control—moving one control point affects only neighboring spans.
- [e-x-p-e-r-i-m-e-n-t-1-9-3d-world-t-o-3d-view](./e-x-p-e-r-i-m-e-n-t-1-9-3d-world-t-o-3d-view/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [projections](./projections/) — Projection maps 3D view-space points to 2D via a projection matrix. Orthographic preserves parallelism; perspective applies foreshortening with a depth-dependent divide by w.
- [e-x-p-e-r-i-m-e-n-t-2-1-back-f-ace-elimina-tion](./e-x-p-e-r-i-m-e-n-t-2-1-back-f-ace-elimina-tion/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [e-x-p-e-r-i-m-e-n-t-2-2-p-ainters](./e-x-p-e-r-i-m-e-n-t-2-2-p-ainters/) — This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.
- [color-space-conversion](./color-space-conversion/) — Color conversion applies nonlinear and linear transforms between spaces (e.g., RGB↔HSV, RGB↔YCbCr). It preserves luminance or separates chroma for operations like enhancement or compression.
