The Midpoint Circle algorithm exploits eight-way symmetry and a midpoint decision parameter to step around a circle. At each iteration it selects E or SE pixels based on the sign of the implicit circle function, requiring only integer updates.

# Midpoint Circle

L A B
E X P E R I M E N T :

MIDPOINT
CIRCLE
GENERA TION
ALGORITHM:
O B J E C T I V E :
To
implement
the
Midpoint
Circle
Generation
Algorithm
and
understand
its
role
in
efficiently
plotting
points
of
a
circle
on
a
raster
grid.
T H E O R Y :
The
Midpoint
Circle
Algorithm
is
an
efficient
approach
for
rasterizing
circles
in
computer
graphics.
By
leveraging
symmetry
and
integer
arithmetic,
it
calculates
points
for
one-eighth
of
the
circle
and
mirrors
them
to
form
the
complete
circle.
This
technique
avoids
trigonometric
computations,
reducing
complexity
and
enhancing
performance.
K e y
P o i n t s
o f
M i d p o i n t
C i r c l e
A l g o r i t h m :
1.
Based
on
the
cir cle
equation:
x2+y2=r2x2+y2=r2,
where
rr
is
the
radius
of
the
circle,
and
(x,y)(x,y)
are
points
on
the
circle.
2.
Incr emental
decision-making:
The
decision
variable
determines
whether
the
next
point
moves
horizontally
or
diagonally .
3.
Exploits
symmetry:
Points
are
computed
for
one
octant
and
reflected
across
all
octants.
A L G O R I T H M
S T E P S :
1.
Start
at
the
topmost
point
of
the
circle:
(x=0,y=r)(x=0,y=r).
2.
Initialize
the
decision
parameter:
p=1−rp=1−r .
3.
Iterate
through
points,
determining
the
next
pixel
based
on
pp:
○
If
p<0p<0:
Move
horizontally .
○
If
p≥0p≥0:
Move
diagonally .
4.
Update
the
decision
parameter
for
each
step.
5.
Reflect
the
calculated
points
across
all
eight
octants
to
complete
the
circle.

E X P E R I M E N T A T I O N
P R O C E D U R E :
1.
Write
a
function
to
implement
the
Midpoint
Circle
Algorithm.
2.
Input
the
center
coordinates
(xc,yc)(xc ,yc )
and
radius
rr.
3.
Initialize
variables
for
the
starting
point
(x=0,y=r)(x=0,y=r)
and
the
decision
parameter
p=1−rp=1−r .
4.
Use
a
loop
to
calculate
points
in
one
octant,
reflecting
these
points
to
plot
the
entire
circle.
5.
Display
the
pixel
coordinates
and
the
plotted
circle
on
a
graphical
window .
C O D E
I M P L E M E N T A T I O N :
Output:
Pixel
coordinates
of
the
circle
points:
(10,
18),
(10,
2),
(18,
10),
(2,
10),
...
○
A
smooth,
symmetric
circle
plotted
on
the
raster
grid.
I N F E R E N C E :
The
Midpoint
Circle
Algorithm
efficiently
draws
circles
using
integer
operations,
making
it
ideal
for
real-time
applications
in
computer
graphics.
By
calculating
points
for
only
one-eighth
of
the
circle
and
mirroring
them,
the
algorithm
significantly
reduces
computational
overhead
while
maintaining
precision
and
symmetry .

L E A R N I N G
O U T C O M E :
●
Learned
how
the
Midpoint
Circle
Algorithm
optimizes
raster
circle
generation
using
symmetry .
●
Understood
the
role
of
decision
variables
in
selecting
the
next
pixel.
●
Gained
experience
implementing
a
fundamental
computer
graphics
algorithm
to
create
smooth,
symmetric
circles.

25

## Build & Run

```bash
g++ -std=c++17 midpoint_circle.cpp -o app
./app
```
