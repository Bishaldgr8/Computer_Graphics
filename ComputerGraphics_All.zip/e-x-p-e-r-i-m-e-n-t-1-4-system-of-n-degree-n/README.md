This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.

# E X P E R I M E N T 1 4 System Of “N” Degree “N”

L A B
E X P E R I M E N T :
1 4 
SYSTEM
OF
“N”
DEGREE
“N”
POL YNOMIALS
O b j e c t i v e :
To
explore
the
solution
of
a
system
of
polynomial
equations
of
degree
"N"
using
numerical
methods.
The
aim
is
to
understand
the
application
of
numerical
techniques
like
Gaussian
elimination,
Newton's
method,
and
other
root-finding
algorithms
to
solve
complex
polynomial
systems.
T h e o r y :
A
polynomial
equation
of
degree
"N"
can
be
expressed
in
the
general
form:
P(x)=a0+a1x+a2x2+
⋯
+aNxN=0P(x)=a0 +a1 x+a2 x2+
⋯
+aN xN=0
Here,
a0,a1,…,aNa0 ,a1 ,…,aN 
are
constants,
and
xx
represents
the
variable.
Solving
a
system
of
such
polynomial
equations
involves
finding
the
set
of
variable
values
that
simultaneously
satisfy
all
equations
in
the
system.
K e y
C o n c e p t s :
1.
P o l y n o m i a l
E q u a t i o n s :
Algebraic
expressions
involving
powers
of
variables
like
x,y,zx,y ,z.
2.
Degr ee
of
a
Polynomial:
The
degree
of
a
polynomial
is
determined
by
the
highest
power
of
the
variable
in
the
equation.
For
instance,
a
quadratic
polynomial
has
degree
2,
while
a
cubic
polynomial
has
degree
3.
3.
System
of
Equations:
A
collection
of
polynomial
equations
sharing
variables,
where
the
goal
is
to
determine
common
solutions
for
all
variables.
4.
Methods
for
Solving
Polynomial
Systems:
○
Analytical
Methods:
Solutions
are
derived
algebraically
for
simpler
systems
but
are
often
impractical
for
higher
degrees.

○
Numerical
Methods:
Iterative
approaches,
such
as
Newton's
method,
Gauss-Seidel
method,
or
Gaussian
elimination,
are
used
for
approximate
solutions
in
complex
systems.
5.
Root-Finding
T echniques:
Methods
like
Newton-Raphson
and
the
Bisection
method
iteratively
approximate
roots
of
polynomial
equations.
6.
Jacobian
Matrix:
For
systems
with
multiple
equations
and
variables,
the
Jacobian
matrix
is
used
to
linearize
the
equations,
facilitating
iterative
solutions
with
techniques
like
Newton's
method.
E x p e r i m e n t a t i o n
P r o c e d u r e :
1 .
D e f i n e
t h e
P o l y n o m i a l
S y s t e m :
Construct
a
system
of
"N"
polynomial
equations,
each
of
degree
"N".
For
instance:
x2+y2−4=0x2+y2−4=0x3−y−1=0x3−y−1=0
2 .
P r o v i d e
I n i t i a l
G u e s s e s :
Choose
initial
approximations
for
the
unknown
variables
x1,x2,…,xNx1 ,x2 ,…,xN .
These
guesses
are
crucial
for
initiating
numerical
methods.
3 .
A p p l y
a
N u m e r i c a l
M e t h o d :
●
N e w t o n ' s
M e t h o d :
○
Linearize
the
system
using
the
Jacobian
matrix.
○
Iteratively
update
guesses
using
the
formula:Xk+1=Xk−J−1(F(Xk))Xk+1 =Xk −J−1(F(Xk ))
4 .
S o l v e
f o r
R o o t s :
Use
root-finding
algorithms
to
iteratively
refine
solutions.
Check
at
each
step
how
close
the
results
are
to
zero.

5 .
V i s u a l i z e
R e s u l t s :
●
For
systems
with
two
or
three
variables,
use
2D
or
3D
plots
to
visualize
polynomial
curves
and
their
intersections.
●
For
larger
systems,
focus
on
numerical
outputs.
C o d e
E x a m p l e :

## Build & Run

```bash
g++ -std=c++17 e_x_p_e_r_i_m_e_n_t_1_4_system_of_n_degree_n.cpp -o app
./app
```
