Bresenham’s line rasterizer uses an integer error term to choose between two neighboring pixels each step. It avoids floating-point arithmetic by maintaining a decision variable derived from the implicit line equation, providing efficient, visually continuous straight lines.

# Bresenham Line

L A B
E X P E R I M E N T :

BRESENHEM’S
LINE
DRA WING
ALGORITHM
O B J E C T I V E :
To
implement
Bresenham's
Line
Drawing
Algorithm
and
understand
its
efficiency
in
generating
lines
on
a
raster
grid,
offering
better
performance
compared
to
traditional
line-drawing
algorithms.
T H E O R Y :
Bresenham's
Line
Drawing
Algorithm
is
a
widely-used
method
for
plotting
a
straight
line
between
two
points
on
a
raster
display .
It
is
an
incremental
scan-conversion
algorithm
that
relies
exclusively
on
integer
arithmetic
to
determine
which
pixel
should
be
activated
to
represent
the
line.
By
avoiding
floating-point
calculations,
the
algorithm
minimizes
computation
and
operates
faster
than
the
DDA
(Digital
Differential
Analyzer)
algorithm.
K e y
P o i n t s
o f
B r e s e n h a m ' s
A l g o r i t h m :
1.
The
algorithm
determines
pixel
positions
based
on
an
error
term,
which
tracks
the
deviation
between
the
ideal
line
and
the
actual
line.
2.
It
uses
only
integer
addition,
subtraction,
and
bitwise
shifts
to
calculate
pixel
positions.
3.
Bresenham's
algorithm
can
handle
all
types
of
slopes
(from
0°
to
90°).
A L G O R I T H M
S T E P S :
1.
I n i t i a l i z e
t h e
s t a r t i n g
a n d
e n d i n g
c o o r d i n a t e s
o f
t h e
l i n e .
2.
C a l c u l a t e
t h e
d i f f e r e n c e s :
○
Compute
dxdx
(difference
in
x-coordinates)
and
dydy
(difference
in
y-coordinates).
3.
Set
up
the
decision
variables:
○
The
initial
decision
variable
p0=2
⋅
dy−dxp0 =2
⋅
dy−dx.
○
If
p0<0p0 <0,
the
next
pixel
is
chosen
without
changing
the
yy-coordinate.
○
If
p0≥0p0 ≥0,
the
next
pixel
increments
both
xx
and
yy-coordinates.

4.
Iterate
thr ough
the
pixels:
○
For
each
step,
update
the
decision
variable
and
determine
the
next
pixel
position.
5.
Stop
once
the
end
point
is
r eached.
E X P E R I M E N T A T I O N
P R O C E D U R E :
1.
W r i t e
t h e
B r e s e n h a m ' s
A l g o r i t h m
F u n c t i o n :
○
Create
a
function
to
implement
the
algorithm
logic.
2.
T ake
Input
for
Line
Coordinates:
○
Input
the
start
and
end
points
of
the
line
either
from
the
user
or
predefined
in
the
program.
3.
Initialize
V ariables:
○
Compute
dxdx,
dydy ,
and
set
the
initial
decision
variable.
4.
Iterate
Thr ough
the
Pixels:
○
For
each
step,
update
the
decision
variable
to
decide
whether
to
increment
the
yy-coordinate.
5.
Output
Results:
○
Display
the
activated
pixel
coordinates.
○
Visualize
the
drawn
line
on
the
graphics
screen.
C O D E
I M P L E M E N T A T I O N :
Output:
○
A
list
of
pixel
coordinates:
(2,2),(3,2),(4,3),(5,3),(6,4),(7,4),(8,5)(2,2),(3,2),(4,3),(5,3),(6,4),(7,4),(8,5).
○
Graphical
representation:
A
straight
line
displayed
on
the
raster
grid
between
the
given
points.
I N F E R E N C E :
Bresenham's
Line
Drawing
Algorithm
is
significantly
more
efficient
than
the
DDA
algorithm
because
it
relies
solely
on
integer
calculations,
making
it
ideal
for
real-time
rendering
in
computer
graphics.
Its
capability
to
handle
various
slopes
and
eliminate

floating-point
operations
enhances
accuracy
and
performance.
This
makes
it
a
preferred
choice
in
raster
graphics
applications
requiring
optimized
computations.
L E A R N I N G
O U T C O M E :
●
Gained
a
practical
understanding
of
Bresenham's
algorithm
and
its
efficient
use
of
integer
operations.
●
Learned
the
importance
of
rasterization
and
decision
variables
in
line-drawing
algorithms.
●
Acquired
foundational
skills
in
implementing
a
core
computer
graphics
algorithm.

19

## Build & Run

```bash
g++ -std=c++17 bresenham_line.cpp -o app
./app
```
