This experiment implements or demonstrates a core computer graphics concept. It discusses the underlying mathematics and provides a reference C++ implementation.

# E X P E R I M E N T 1 9 3D World T O 3D View

L A B
E X P E R I M E N T :
1 9
3D
WORLD
T O
3D
VIEW
COORDINA TE
TRANSFORMA TION
O B J E C T I V E
To
understand
and
implement
the
transformation
of
3D
coordinates
from
the
World
Coordinate
System
(WCS)
to
the
View
Coordinate
System
(VCS),
a
fundamental
step
in
the
3D
graphics
rendering
pipeline.
H A R D W A R E
E N V I R O N M E N T
1.
Processor
:
Intel
Core
i3
or
higher .
2.
RAM:

GB
or
more.
3.
Graphics:
Integrated
or
dedicated
GPU
supporting
OpenGL.
S O F T W A R E
E N V I R O N M E N T
1.
Operating
System
:
Windows/Linux/macOS.
2.
Programming
Language:
C++
with
OpenGL
and
GLUT
libraries.
3.
Compiler:
GCC
or
equivalent
supporting
OpenGL.
T H E O R Y
The
transformation
from
WCS
to
VCS
aligns
the
world
coordinate
system
to
the
camera’ s
perspective.
This
transformation
consists
of
two
steps:
1.
Translation:
Moves
the
world
origin
to
the
camera's
position.
2.
Rotation:
Aligns
the
world
axes
with
the
camera’ s
view
direction
and
"up"
vector .
View
Reference
Coordinate
System
●
View
Origin
(E):
Camera
position.
●
View
Direction
(N):
Direction
the
camera
is
facing.
●
View
Up
Vector
(V):
Defines
the
camera's
"up"
orientation.
Transformation
Matrix
The
combined
transformation
matrix
is:
Mview=R
⋅
TMview =R
⋅
T

Where:
●
TT:
Translation
matrix
(moves
origin
to
the
camera
position).
●
RR:
Rotation
matrix
(aligns
axes
with
N,U,VN,U,V).
E X P E R I M E N T A T I O N
P R O C E D U R E
1.
Define
Camera
Parameters
:
○
Position
(EE):
Camera
position.
○
Target
(TT):
Point
the
camera
is
looking
at.
○
Up
Vector
(VV):
Defines
the
"up"
direction
for
the
camera.
2.
Compute
Basis
Vectors
for
the
View
Coordinate
System:
○
N=(E−T)
∥
E−T
∥
N=
∥
E−T
∥
(E−T) :
Normalized
vector
pointing
from
the
target
to
the
camera.
○
U=V×N
∥
V×N
∥
U=
∥
V×N
∥
V×N :
Normalized
vector
perpendicular
to
VV
and
NN.
○
V′=N×UV′=N×U:
Orthogonal
"up"
vector
for
the
view
coordinate
system.
3.
Construct
Transformation
Matrices:
○
Rotation
Matrix
(RR)
is
formed
using
U,V′,NU,V′,N.
○
Translation
Matrix
(TT)
moves
EE
to
the
origin.
4.
Combine
RR
and
TT
to
create
MviewMview  .
5.
Apply
MviewMview 
to
world
points.
6.
Visualize
Results:
Render
transformed
points
in
OpenGL.
C O D E

## Build & Run

```bash
g++ -std=c++17 e_x_p_e_r_i_m_e_n_t_1_9_3d_world_t_o_3d_view.cpp -o app
./app
```
